#include <stdio.h>

int main(void){
int n;
int i;
scanf("%d", &n);


for (i = 0; i < n ; i+= 2) {

	printf("%d", i);
printf("\n");
};
return 0;
}
